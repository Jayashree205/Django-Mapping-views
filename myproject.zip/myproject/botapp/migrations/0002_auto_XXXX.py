# 0002_auto_XXXX.py (or similar)

from django.db import migrations, models

class Migration(migrations.Migration):

    dependencies = [
        ('botapp', '0001_initial'),  # Ensure the dependency is correct
    ]

    operations = [
        
        migrations.AddField(
            model_name='conversation',
            name='bot_response',
            field=models.TextField(default='Default response'),
        ),
    ]
