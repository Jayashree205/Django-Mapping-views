from django.db import models
import joblib
model = ...  # Assume 'model' is a trained machine learning model
joblib.dump(model, 'model.pkl')
import joblib
model = joblib.load('model.pkl')

class Conversation(models.Model):
    user_input = models.TextField()
    bot_response = models.TextField(default='Default response')  # Ensure this is updated
    timestamp = models.DateTimeField(auto_now_add=True)

class Destination(models.Model):
    name = models.CharField(max_length=255)
    description = models.TextField()

class Flight(models.Model):
    departure = models.CharField(max_length=255)
    arrival = models.CharField(max_length=255)
    date = models.DateField()
    time = models.TimeField()
