from django.urls import path
from . import views

urlpatterns = [
    path('chatbot/', views.chatbot, name='chatbot'),
    path('book_flight/', views.book_flight, name='book_flight'),
    path('destinations/', views.destinations, name='destinations'),
]

