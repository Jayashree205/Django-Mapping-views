from django.shortcuts import render
from .models import Conversation, Destination, Flight
import joblib  # For loading the trained model
from nltk.stem.lancaster import LancasterStemmer

# Instantiate LancasterStemmer
stemmer = LancasterStemmer()
model = joblib.load("C:/Users/Jayashree/Desktop/django/myproject/model.pkl")
vectorizer = joblib.load("C:/Users/Jayashree/Desktop/django/myproject/models/vectorizer.pkl")

def chatbot(request):
    if request.method == 'POST':
        input_text = request.POST.get('input_text', '').strip()
        if not input_text:
            return render(request, 'chatbot.html', {'output_text': 'No input provided. Please try again!'})

        # Preprocess and predict
        input_text = stemmer.stem(input_text)
        input_features = vectorizer.transform([input_text])  # Convert input to feature vector
        output_text = model.predict(input_features)[0]

        return render(request, 'chatbot.html', {'output_text': output_text})

    return render(request, 'chatbot.html')

def book_flight(request):
    if request.method == 'POST':
        departure = request.POST.get('departure')
        arrival = request.POST.get('arrival')
        date = request.POST.get('date')
        time = request.POST.get('time')
        flight = Flight(departure=departure, arrival=arrival, date=date, time=time)
        flight.save()
        return render(request, 'flight_booked.html')
    return render(request, 'book_flight.html')

def destinations(request):
    destinations = Destination.objects.all()
    return render(request, 'destinations.html', {'destinations': destinations})
